<?php
return [
    //don't change them..(the difference between any 
    //two consecutive stages should be 1 and exactly 1 )
    0=>'VOID',
    1=>'PART ONE',
    2=>'PART TWO',
    3=>'END OF LEAGUE',
    4=>'START OF ALL STARS',
    5=>'END OF ALL STARS',
    'PART ONE'=>1,
    'PART TWO'=>2,
    'END OF LEAGUE'=>3,
    'START OF ALL STARS'=>4,
    'END OF ALL STARS'=>5,
    'VOID'=>0
    
];